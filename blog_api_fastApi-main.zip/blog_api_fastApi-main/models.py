from sqlalchemy import Column, Integer, String, DateTime, Text
from database import Base
import datetime

class Article(Base):
    __tablename__ = "articles"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    author = Column(String, nullable=False)
    date = Column(DateTime, default=datetime.datetime.utcnow)
    category = Column(String, index=True)
    tags = Column(String)