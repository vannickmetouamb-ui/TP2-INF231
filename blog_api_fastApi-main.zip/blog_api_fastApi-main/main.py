from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
import models, schemas, crud, database

# Création des tables
models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="Blog API - Gestion d'Articles", version="1.0.0")

@app.post("/api/articles", response_model=schemas.ArticleResponse, status_code=status.HTTP_201_CREATED)
def create_article(article: schemas.ArticleCreate, db: Session = Depends(database.get_db)):
    return crud.create_article(db=db, article=article)

@app.get("/api/articles", response_model=List[schemas.ArticleResponse])
def read_articles(category: Optional[str] = None, author: Optional[str] = None, db: Session = Depends(database.get_db)):
    return crud.get_articles(db, category=category, author=author)

@app.get("/api/articles/search", response_model=List[schemas.ArticleResponse])
def search_articles(query: str, db: Session = Depends(database.get_db)):
    return db.query(models.Article).filter(
        models.Article.title.contains(query) | models.Article.content.contains(query)
    ).all()

@app.get("/api/articles/{id}", response_model=schemas.ArticleResponse)
def read_article(id: int, db: Session = Depends(database.get_db)):
    db_article = db.query(models.Article).filter(models.Article.id == id).first()
    if db_article is None:
        raise HTTPException(status_code=404, detail="Article non trouvé")
    return db_article

@app.put("/api/articles/{id}", response_model=schemas.ArticleResponse)
def update_article(id: int, article: schemas.ArticleUpdate, db: Session = Depends(database.get_db)):
    db_article = crud.update_article(db, id, article)
    if not db_article:
        raise HTTPException(status_code=404, detail="Article non trouvé")
    return db_article

@app.delete("/api/articles/{id}")
def delete_article(id: int, db: Session = Depends(database.get_db)):
    success = crud.delete_article(db, id)
    if not success:
        raise HTTPException(status_code=404, detail="Article non trouvé")
    return {"message": "Article supprimé avec succès"}