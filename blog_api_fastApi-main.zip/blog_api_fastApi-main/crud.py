from sqlalchemy.orm import Session
import models, schemas

def get_articles(db: Session, category: str = None, author: str = None):
    query = db.query(models.Article)
    if category:
        query = query.filter(models.Article.category == category)
    if author:
        query = query.filter(models.Article.author == author)
    return query.all()

def create_article(db: Session, article: schemas.ArticleCreate):
    db_article = models.Article(**article.dict())
    db.add(db_article)
    db.commit()
    db.refresh(db_article)
    return db_article

def update_article(db: Session, article_id: int, article_data: schemas.ArticleUpdate):
    db_article = db.query(models.Article).filter(models.Article.id == article_id).first()
    if db_article:
        for key, value in article_data.dict(exclude_unset=True).items():
            setattr(db_article, key, value)
        db.commit()
        db.refresh(db_article)
    return db_article

def delete_article(db: Session, article_id: int):
    db_article = db.query(models.Article).filter(models.Article.id == article_id).first()
    if db_article:
        db.delete(db_article)
        db.commit()
        return True
    return False