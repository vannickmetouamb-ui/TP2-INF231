# 📝 Blog API - Backend (FastAPI & SQLite)

Cette API est la première partie d'un système de gestion de blog simple permettant la gestion complète d'articles. Développée avec **FastAPI**, elle intègre nativement une documentation interactive (Swagger) et utilise **SQLite** pour la persistance des données.

## 🚀 Fonctionnalités

L'API implémente les fonctionnalités suivantes :
- **Création d'articles** : Enregistrement avec titre, contenu, auteur, catégorie et tags.
- **Lecture des articles** : Récupération de la liste complète ou filtrée par catégorie et auteur.
- **Lecture d'un article unique** : Accès aux détails via l'ID.
- **Recherche textuelle** : Recherche de mots-clés dans le titre ou le contenu.
- **Modification** : Mise à jour des informations d'un article existant.
- **Suppression** : Suppression définitive d'un article via son ID.

## 🛠️ Technologies utilisées

- **Langage :** Python 3.10+
- **Framework :** FastAPI (Performance et validation automatique)
- **Base de données :** SQLite (Base de données locale légère)
- **ORM :** SQLAlchemy (Gestion des modèles de données)
- **Validation :** Pydantic (Schémas de données)
- **Documentation :** Swagger UI (OpenAPI)

## 📋 Prérequis

- Système : **Kali Linux** (ou toute autre distribution Linux/Windows/Mac)
- Python 3.10 ou supérieur installé.
- Gestionnaire de paquets `pip`.

## 📥 Installation

1. **Cloner le projet :**
   ```bash
   git clone https://github.com/V


2. **Créer un environnement virtuel et l'activer :**
     ```bash
      python3 -m venv venv
      source venv/bin/activate
3. **Installer les dépendances nécessaires :**
      ```bash
      uvicorn main:app --reload


## Le serveur sera opérationnel sur : http://127.0.0.1:8000

📖 Documentation de l'API (Swagger)
L'une des forces de ce backend est sa documentation auto-générée. Une fois le serveur lancé, accédez aux interfaces suivantes :

* Swagger UI : http://127.0.0.1:8000/docs (Idéal pour tester les endpoints)

* ReDoc : http://127.0.0.1:8000/redoc

📡 Liste des Endpoints
Méthode	Endpoint	Description
POST	/api/articles	Créer un article (ID généré auto)
GET	/api/articles	Lister les articles (Filtres category, author dispos)
GET	/api/articles/{id}	Consulter un article spécifique par ID
GET	/api/articles/search	Rechercher via le paramètre query
PUT	/api/articles/{id}	Modifier un article existant
DELETE	/api/articles/{id}	Supprimer un article
      