from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional

class ArticleBase(BaseModel):
    title: str = Field(..., min_length=3, example="Mon premier article")
    content: str = Field(..., min_length=10)
    author: str = Field(..., example="Jean Dupont")
    category: str
    tags: str

class ArticleCreate(ArticleBase):
    pass

class ArticleUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[str] = None

class ArticleResponse(ArticleBase):
    id: int
    date: datetime

    class Config:
        from_attributes = True